#include <stdio.h>

void main()
{
    int arr1[100], arr2[100];
    int a, i, j, ct;




       printf("Input the number of elements to be stored in the array :");
       scanf("%d",&a);

       printf("Input %d elements in the array :\n",a);
       for(i=0;i<a;i++)
            {
	      printf("element - %d : ",i);
	      scanf("%d",&arr1[i]);
		  arr2[i] = -1;
	    }
    for(i=0; i<a; i++)
    {
        ct = 1;
        for(j=i+1; j<a; j++)
        {
            if(arr1[i]==arr1[j])
            {
                ct++;
                arr2[j] = 0;
            }
        }

        if(arr2[i]!=0)
        {
            arr2[i] = ct;
        }
    }
    printf("\nThe frequency of all elements of array : \n");
    for(i=0; i<a; i++)
    {
        if(arr2[i]!=0)
        {
            printf("%d occurs %d times\n", arr1[i], arr2[i]);
        }
    }
}
