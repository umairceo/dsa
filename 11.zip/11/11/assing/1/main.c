#include <stdio.h>

void  main()
{
    int arr[10];
    int a;

    printf("Input 10 elements in the array :\n");
    for(a=0; a<10; a++)
    {
	    printf("element - %d : ",a);
        scanf("%d", &arr[a]);
    }

    printf("\nElements in array are: ");
    for(a=0; a<10; a++)
    {
        printf("%d  ", arr[a]);
    }
    printf("\n");
}
